import React from 'react'
import './Home.css'
function Home() {
    return (
        <div>
            <div className="home">
                <div className=' mt-3'><p>One of a Kind </p>
                    <p> An epitome of Generous Hospitality</p>
                    <div className="btn  btn-success ">Book Now!</div>
                </div>
            </div>

            <div className="form">
                <form action="" method="post">
                   <input type="text"  name="" id="" />
                </form>
            </div>

        </div>
    )
}
export default Home